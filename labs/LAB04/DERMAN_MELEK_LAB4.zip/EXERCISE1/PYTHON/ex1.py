import numpy as np
import matplotlib.pyplot as plt

#define constants

k = np.zeros(15)
for i in range(15):
    k[i] = i+1

h = np.zeros(15)
for i in range(15):
    h[i] = 10**(-k[i])

print(h)

#define functions 

def f(x):
    return np.exp(x)

def sigma_1(h_1):
    return (f(h_1)-f(0))/h_1

y_sigma_1 = np.log10(np.abs(sigma_1(h)-1))
x_sigma = np.log10(h)

def sigma_2(h_1):
    return (f(h_1)-f(-h_1))/(2*h_1)

y_sigma_2 = np.log10(np.abs(sigma_2(h)-1))

def sigma_3(h_1):
    return (1/3)*(4*sigma_2(h_1)-sigma_2(2*h_1))

y_sigma_3 = np.log10(np.abs(sigma_3(h)-1))

m1 = (np.log10(np.abs(sigma_1(h[7])-1))-np.log10(np.abs(sigma_1(h[0]-1))))/(np.log10(h[7])-np.log10(h[0]))
print('m1=', m1)

m2 = (np.log10(np.abs(sigma_2(h[5])-1))-np.log10(np.abs(sigma_2(h[0]-1))))/(np.log10(h[5])-np.log10(h[0]))
print('m2', m2)

m3 = (np.log10(np.abs(sigma_3(h[3])-1))-np.log10(np.abs(sigma_3(h[0]-1))))/(np.log10(h[3])-np.log10(h[0]))
print('m3', m3)

fig = plt.figure(figsize = (10,8))
plt.plot(x_sigma, y_sigma_1, 'b', label = "sigma_1", )
plt.plot(x_sigma, y_sigma_2, 'r', label = "sigma_2")
plt.plot(x_sigma, y_sigma_3, 'g', label = "sigma_3")
plt.title('3 Different Approximations for Difference Quotients')
plt.grid()
plt.xlabel('x')
plt.ylabel('y')
plt.savefig("Difference Quotients")
plt.show()