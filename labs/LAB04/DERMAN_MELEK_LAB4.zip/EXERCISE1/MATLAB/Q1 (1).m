k = [1:15];
h = 10.^-k;
result1 = sigma1(h);
figure(1)
plot(log10(h),log10(abs(result1-1)))

hold on
result2 = sigma2(h);
%figure(2)
plot(log10(h),log10(abs(result2-1)))

hold on
result3 = sigma3(h);
%figure(2)
plot(log10(h),log10(abs(result3-1)))

function [y] = sigma1(x)
    y = zeros(1,length(x));
    for i = 1:length(x)
    y(1,i) = (exp(x(1,i)) - exp(0)) / x(1,i);
    end
end

function [y] = sigma2(x)
    y = zeros(1,length(x));
    for i = 1:length(x)
    y(1,i) = (exp(x(1,i)) - exp(-x(1,i))) / (2.*x(1,i));
    end
end

function [y] = sigma3(x)
    y = zeros(1,length(x));
    for i = 1:length(x)
    y(1,i) =  1/3 .* ((4.* (exp(x(1,i)) - exp(-x(1,i))) / (2.*x(1,i))) - (1.* (exp(2.*x(1,i)) - exp(-2.*x(1,i))) / (2.*2.*x(1,i))));
    end
end


