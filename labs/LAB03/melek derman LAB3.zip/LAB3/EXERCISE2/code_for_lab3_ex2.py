from tkinter import N
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt

#define data points

n = 256
x = np.zeros(n)
for j in range(0,n):
    x[j] = j/n
    print("x[", j, "]=", x[j])
    j += 1

#define f(x)=x function as f1

f1 = np.zeros(n)
for i in range(0,n):
    f1[i] = x[i]
    i += 1

#define f(x)=x(1-x) function as f2

f2 = np.zeros(n)
for i in range(0,n):
    f2[i] = x[i]*(1-x[i])

#use fft function to compute coefficients
y1 = np.fft.fft(f1)
y2 = np.fft.fft(f2)

print(y1)

#set the middle n-2m-1 coefficients to zero 
m = 25
for i in range(0,n):
    if i>m and i<n-m:
        y1[i] = 0
        y2[i] = 0
    i += 1

#use ifft function for inverse Fourier Transform
y1i = np.fft.ifft(y1)
y2i = np.fft.ifft(y2)
print(y1i)
print(y2i)

#compute L2 Error
err = np.zeros(n)
e0 = 0
for j in range(0,n):
    err[j] = e0 + (f1[j]-np.real(y1i[j]))**2*x[j]
    e0 = err[j]
    j += 1

print("the L2 error for |f-f_25|", e0/n)

#plot and save functions
plt.figure()
plt.plot(x, np.real(y1i))
plt.plot(x, f1)
plt.title('figure for f1(x) = x and Re(f_25(x))')
plt.xlabel('x data points')
plt.ylabel('f and fm functions')
plt.savefig("25f1")

plt.figure()
plt.plot(x, np.real(y2i))
plt.plot(x, f2)
plt.title('figure for f2(x) = x(1-x) and Re(f_25(x))')
plt.xlabel('x data points')
plt.ylabel('f and fm functions')
plt.savefig("25f2")

plt.show()